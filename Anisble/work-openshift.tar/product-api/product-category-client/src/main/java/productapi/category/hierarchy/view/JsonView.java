package productapi.category.hierarchy.view;

public class JsonView {

    private JsonView() {}

    public static class WebShop {}

    public static class Management extends WebShop {}
}
