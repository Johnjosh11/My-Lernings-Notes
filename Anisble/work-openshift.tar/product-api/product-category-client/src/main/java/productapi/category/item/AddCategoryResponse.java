package productapi.category.item;

public class AddCategoryResponse {

    public final Integer categoryId;

    public AddCategoryResponse(Integer categoryId) {
        this.categoryId = categoryId;
    }
}
