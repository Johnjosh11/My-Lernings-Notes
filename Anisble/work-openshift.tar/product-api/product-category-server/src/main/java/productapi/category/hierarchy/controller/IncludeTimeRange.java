package productapi.category.hierarchy.controller;

public enum IncludeTimeRange {
    ALL,
    ACTIVE_AND_PAST_30_DAYS
}
